1. generate 3D params of human faces

```bash
python inference.py --img_list example/file_list.txt --img_prefix example/Images --save_dir results
```
